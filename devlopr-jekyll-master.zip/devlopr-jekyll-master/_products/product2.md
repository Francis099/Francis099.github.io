---
identifier: jekyll-starry-night-2
name: John Doe Mug
price: 10
image: /assets/img/products/product2.jpg
---

# John Doe Mug

This is a high-quality replica of The Starry Night by the Dutch post-impressionist painter Vincent van Gogh. Using brand new techniques such as magneto-reluctance and capacitive reactance, we were able to reproduce the original colours with a 99.99% accuracy.